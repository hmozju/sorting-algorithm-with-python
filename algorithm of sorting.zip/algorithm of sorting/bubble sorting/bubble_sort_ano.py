# ! /usr/bin/env python
#-*-coding:cp936-*-
#-*-UTF-8-*-


def bubble_sort_ano(lists):
    count = len(lists)
    flag = True
    while(flag):
        flag = False
        for i in range(0,count-1):
             if lists[i] > lists[i+1]:
                 lists[i],lists[i+1] = lists[i+1],lists[i]
                 flag = True
    return lists
        
   
