#!/usr/bin/env python
#-*-UTF-8-*-
#-*-coding:cp936-*-

# @author: M.Huang
# date: 5.14.2017
# intro: another version of insertion sort of algorithm





# 另一个版本（简版）

def insert_sort(lists):
    count = len(lists)
    if count == 1: return lists
    for i in range(1,count):
        for j in range(i,0,-1): 
            if lists[j] < lists[ j-1]:
                lists[j], lists[j-1] = lists[j-1], lists[j]
    return lists
