# !/usr/bin/env python
#-*-coding:cp936-*-
#-*-UTF-8-*-

# @author: M.Huang
# date: 5.14.2017
# intro: selection sorting of algorithm with python

def select_sort(lists):
    count = len(lists)
    for i in range(0,count):
        min = i
        for j in range(i+1,count):
            if lists[min] > lists[j]:
                min = j
        lists[i], lists[min] = lists[min], lists[i]
    return lists
