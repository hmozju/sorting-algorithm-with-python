# !/usr/bin/env python
#-*-coding:cp936-*-
#-*-UTF-8-*-

# @author: M.Huang
# date: 5.14.2017
# intro: selection sorting of algorithm with python

def select_sort_ano(lists):
    count = len(lists)
    flag = True
    while(flag):
        flag = False
        for i in range(0,count-1):
        #min =  i
            if lists[i] > lists[i+1]:
                 lists[i], lists[i+1] = lists[i+1], lists[i]
                 flag = True
    return lists

        
    
